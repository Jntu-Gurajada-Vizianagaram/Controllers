﻿namespace College_Project
{
    partial class frmmaincontent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmmaincontent));
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startPageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.facultyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sBTETToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notificationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentPortalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sBTETToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.feePortalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resultsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.googleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.googleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gMailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.youTubeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faceBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.whatsAppWebToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.instagramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.back = new System.Windows.Forms.Button();
            this.frwd = new System.Windows.Forms.Button();
            this.refresh = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.conn = new System.Windows.Forms.Button();
            this.notconn = new System.Windows.Forms.Button();
            this.sbrowser = new System.Windows.Forms.RadioButton();
            this.ebrowser = new System.Windows.Forms.RadioButton();
            this.searchbar = new System.Windows.Forms.TextBox();
            this.search = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dt = new System.Windows.Forms.Label();
            this.time = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button1.Location = new System.Drawing.Point(813, 538);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "NEXT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.AllowDrop = true;
            this.menuStrip1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem,
            this.sBTETToolStripMenuItem,
            this.sBTETToolStripMenuItem1,
            this.googleToolStripMenuItem,
            this.contactToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(3, 3);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(474, 31);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.menuToolStripMenuItem.Checked = true;
            this.menuToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startPageToolStripMenuItem,
            this.loginToolStripMenuItem,
            this.registerToolStripMenuItem,
            this.backToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(60, 27);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // startPageToolStripMenuItem
            // 
            this.startPageToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.startPageToolStripMenuItem.Name = "startPageToolStripMenuItem";
            this.startPageToolStripMenuItem.Size = new System.Drawing.Size(136, 28);
            this.startPageToolStripMenuItem.Text = "Start";
            this.startPageToolStripMenuItem.Click += new System.EventHandler(this.startPageToolStripMenuItem_Click);
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(136, 28);
            this.loginToolStripMenuItem.Text = "Login ";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // registerToolStripMenuItem
            // 
            this.registerToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.registerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.facultyToolStripMenuItem,
            this.studentToolStripMenuItem,
            this.guestToolStripMenuItem});
            this.registerToolStripMenuItem.Name = "registerToolStripMenuItem";
            this.registerToolStripMenuItem.Size = new System.Drawing.Size(136, 28);
            this.registerToolStripMenuItem.Text = "Register";
            // 
            // facultyToolStripMenuItem
            // 
            this.facultyToolStripMenuItem.Name = "facultyToolStripMenuItem";
            this.facultyToolStripMenuItem.Size = new System.Drawing.Size(135, 28);
            this.facultyToolStripMenuItem.Text = "Faculty ";
            this.facultyToolStripMenuItem.Click += new System.EventHandler(this.facultyToolStripMenuItem_Click);
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(135, 28);
            this.studentToolStripMenuItem.Text = "Student";
            this.studentToolStripMenuItem.Click += new System.EventHandler(this.studentToolStripMenuItem_Click);
            // 
            // guestToolStripMenuItem
            // 
            this.guestToolStripMenuItem.Name = "guestToolStripMenuItem";
            this.guestToolStripMenuItem.Size = new System.Drawing.Size(135, 28);
            this.guestToolStripMenuItem.Text = "Guest";
            this.guestToolStripMenuItem.Click += new System.EventHandler(this.guestToolStripMenuItem_Click);
            // 
            // backToolStripMenuItem
            // 
            this.backToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new System.Drawing.Size(136, 28);
            this.backToolStripMenuItem.Text = "Back";
            this.backToolStripMenuItem.Click += new System.EventHandler(this.backToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(136, 28);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // sBTETToolStripMenuItem
            // 
            this.sBTETToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem,
            this.notificationsToolStripMenuItem,
            this.studentPortalToolStripMenuItem});
            this.sBTETToolStripMenuItem.Name = "sBTETToolStripMenuItem";
            this.sBTETToolStripMenuItem.Size = new System.Drawing.Size(68, 27);
            this.sBTETToolStripMenuItem.Text = "SBTET";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(178, 28);
            this.homeToolStripMenuItem.Text = "Home";
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.homeToolStripMenuItem_Click);
            // 
            // notificationsToolStripMenuItem
            // 
            this.notificationsToolStripMenuItem.Name = "notificationsToolStripMenuItem";
            this.notificationsToolStripMenuItem.Size = new System.Drawing.Size(178, 28);
            this.notificationsToolStripMenuItem.Text = "Notifications";
            this.notificationsToolStripMenuItem.Click += new System.EventHandler(this.notificationsToolStripMenuItem_Click);
            // 
            // studentPortalToolStripMenuItem
            // 
            this.studentPortalToolStripMenuItem.Name = "studentPortalToolStripMenuItem";
            this.studentPortalToolStripMenuItem.Size = new System.Drawing.Size(178, 28);
            this.studentPortalToolStripMenuItem.Text = "Student Portal";
            this.studentPortalToolStripMenuItem.Click += new System.EventHandler(this.studentPortalToolStripMenuItem_Click);
            // 
            // sBTETToolStripMenuItem1
            // 
            this.sBTETToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem1,
            this.feePortalToolStripMenuItem,
            this.resultsToolStripMenuItem});
            this.sBTETToolStripMenuItem1.Name = "sBTETToolStripMenuItem1";
            this.sBTETToolStripMenuItem1.Size = new System.Drawing.Size(136, 27);
            this.sBTETToolStripMenuItem1.Text = "SBTET (Server2)";
            // 
            // homeToolStripMenuItem1
            // 
            this.homeToolStripMenuItem1.Name = "homeToolStripMenuItem1";
            this.homeToolStripMenuItem1.Size = new System.Drawing.Size(149, 28);
            this.homeToolStripMenuItem1.Text = "Home";
            this.homeToolStripMenuItem1.Click += new System.EventHandler(this.homeToolStripMenuItem1_Click);
            // 
            // feePortalToolStripMenuItem
            // 
            this.feePortalToolStripMenuItem.Name = "feePortalToolStripMenuItem";
            this.feePortalToolStripMenuItem.Size = new System.Drawing.Size(149, 28);
            this.feePortalToolStripMenuItem.Text = "Fee Portal";
            this.feePortalToolStripMenuItem.Click += new System.EventHandler(this.feePortalToolStripMenuItem_Click);
            // 
            // resultsToolStripMenuItem
            // 
            this.resultsToolStripMenuItem.Name = "resultsToolStripMenuItem";
            this.resultsToolStripMenuItem.Size = new System.Drawing.Size(149, 28);
            this.resultsToolStripMenuItem.Text = "Results";
            this.resultsToolStripMenuItem.Click += new System.EventHandler(this.resultsToolStripMenuItem_Click);
            // 
            // googleToolStripMenuItem
            // 
            this.googleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.googleToolStripMenuItem1,
            this.gMailToolStripMenuItem,
            this.youTubeToolStripMenuItem,
            this.faceBookToolStripMenuItem,
            this.whatsAppWebToolStripMenuItem,
            this.instagramToolStripMenuItem});
            this.googleToolStripMenuItem.Name = "googleToolStripMenuItem";
            this.googleToolStripMenuItem.Size = new System.Drawing.Size(68, 27);
            this.googleToolStripMenuItem.Text = "Google";
            // 
            // googleToolStripMenuItem1
            // 
            this.googleToolStripMenuItem1.Name = "googleToolStripMenuItem1";
            this.googleToolStripMenuItem1.Size = new System.Drawing.Size(182, 28);
            this.googleToolStripMenuItem1.Text = "Google";
            this.googleToolStripMenuItem1.Click += new System.EventHandler(this.googleToolStripMenuItem1_Click);
            // 
            // gMailToolStripMenuItem
            // 
            this.gMailToolStripMenuItem.Name = "gMailToolStripMenuItem";
            this.gMailToolStripMenuItem.Size = new System.Drawing.Size(182, 28);
            this.gMailToolStripMenuItem.Text = "G-Mail";
            this.gMailToolStripMenuItem.Click += new System.EventHandler(this.gMailToolStripMenuItem_Click);
            // 
            // youTubeToolStripMenuItem
            // 
            this.youTubeToolStripMenuItem.Name = "youTubeToolStripMenuItem";
            this.youTubeToolStripMenuItem.Size = new System.Drawing.Size(182, 28);
            this.youTubeToolStripMenuItem.Text = "YouTube";
            this.youTubeToolStripMenuItem.Click += new System.EventHandler(this.youTubeToolStripMenuItem_Click);
            // 
            // faceBookToolStripMenuItem
            // 
            this.faceBookToolStripMenuItem.Name = "faceBookToolStripMenuItem";
            this.faceBookToolStripMenuItem.Size = new System.Drawing.Size(182, 28);
            this.faceBookToolStripMenuItem.Text = "FaceBook";
            this.faceBookToolStripMenuItem.Click += new System.EventHandler(this.faceBookToolStripMenuItem_Click);
            // 
            // whatsAppWebToolStripMenuItem
            // 
            this.whatsAppWebToolStripMenuItem.Name = "whatsAppWebToolStripMenuItem";
            this.whatsAppWebToolStripMenuItem.Size = new System.Drawing.Size(182, 28);
            this.whatsAppWebToolStripMenuItem.Text = "WhatsApp Web";
            this.whatsAppWebToolStripMenuItem.Click += new System.EventHandler(this.whatsAppWebToolStripMenuItem_Click);
            // 
            // instagramToolStripMenuItem
            // 
            this.instagramToolStripMenuItem.Name = "instagramToolStripMenuItem";
            this.instagramToolStripMenuItem.Size = new System.Drawing.Size(182, 28);
            this.instagramToolStripMenuItem.Text = "Instagram";
            this.instagramToolStripMenuItem.Click += new System.EventHandler(this.instagramToolStripMenuItem_Click);
            // 
            // contactToolStripMenuItem
            // 
            this.contactToolStripMenuItem.Name = "contactToolStripMenuItem";
            this.contactToolStripMenuItem.Size = new System.Drawing.Size(73, 27);
            this.contactToolStripMenuItem.Text = "Contact";
            this.contactToolStripMenuItem.Click += new System.EventHandler(this.contactToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(61, 27);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.webBrowser1.Location = new System.Drawing.Point(3, 71);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.ScriptErrorsSuppressed = true;
            this.webBrowser1.Size = new System.Drawing.Size(893, 461);
            this.webBrowser1.TabIndex = 6;
            this.webBrowser1.Url = new System.Uri("http://www.google.com", System.UriKind.Absolute);
            this.webBrowser1.Navigated += new System.Windows.Forms.WebBrowserNavigatedEventHandler(this.webBrowser1_Navigated);
            // 
            // back
            // 
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back.Location = new System.Drawing.Point(3, 35);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(26, 22);
            this.back.TabIndex = 7;
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.button2_Click);
            // 
            // frwd
            // 
            this.frwd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.frwd.Location = new System.Drawing.Point(32, 35);
            this.frwd.Name = "frwd";
            this.frwd.Size = new System.Drawing.Size(26, 22);
            this.frwd.TabIndex = 8;
            this.frwd.UseVisualStyleBackColor = true;
            this.frwd.Click += new System.EventHandler(this.frwd_Click);
            // 
            // refresh
            // 
            this.refresh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.refresh.Location = new System.Drawing.Point(61, 35);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(26, 22);
            this.refresh.TabIndex = 9;
            this.refresh.UseVisualStyleBackColor = true;
            this.refresh.Click += new System.EventHandler(this.refresh_Click);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Location = new System.Drawing.Point(90, 35);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(26, 22);
            this.button2.TabIndex = 10;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(815, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 11;
            // 
            // conn
            // 
            this.conn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.conn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.conn.Location = new System.Drawing.Point(826, 3);
            this.conn.Name = "conn";
            this.conn.Size = new System.Drawing.Size(36, 32);
            this.conn.TabIndex = 12;
            this.conn.UseVisualStyleBackColor = true;
            // 
            // notconn
            // 
            this.notconn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.notconn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.notconn.Location = new System.Drawing.Point(826, 2);
            this.notconn.Name = "notconn";
            this.notconn.Size = new System.Drawing.Size(36, 32);
            this.notconn.TabIndex = 13;
            this.notconn.UseVisualStyleBackColor = true;
            this.notconn.Click += new System.EventHandler(this.notconn_Click);
            // 
            // sbrowser
            // 
            this.sbrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.sbrowser.AutoSize = true;
            this.sbrowser.BackColor = System.Drawing.Color.Transparent;
            this.sbrowser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.sbrowser.Checked = true;
            this.sbrowser.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sbrowser.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.sbrowser.Location = new System.Drawing.Point(590, 12);
            this.sbrowser.Name = "sbrowser";
            this.sbrowser.Size = new System.Drawing.Size(104, 22);
            this.sbrowser.TabIndex = 14;
            this.sbrowser.TabStop = true;
            this.sbrowser.Text = "Self Browser";
            this.sbrowser.UseVisualStyleBackColor = false;
            this.sbrowser.CheckedChanged += new System.EventHandler(this.sbrowser_CheckedChanged);
            // 
            // ebrowser
            // 
            this.ebrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ebrowser.AutoSize = true;
            this.ebrowser.BackColor = System.Drawing.Color.Transparent;
            this.ebrowser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ebrowser.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ebrowser.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.ebrowser.Location = new System.Drawing.Point(691, 12);
            this.ebrowser.Name = "ebrowser";
            this.ebrowser.Size = new System.Drawing.Size(129, 22);
            this.ebrowser.TabIndex = 14;
            this.ebrowser.Text = "External Browser";
            this.ebrowser.UseVisualStyleBackColor = false;
            this.ebrowser.CheckedChanged += new System.EventHandler(this.ebrowser_CheckedChanged);
            // 
            // searchbar
            // 
            this.searchbar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchbar.Location = new System.Drawing.Point(119, 35);
            this.searchbar.Multiline = true;
            this.searchbar.Name = "searchbar";
            this.searchbar.Size = new System.Drawing.Size(330, 22);
            this.searchbar.TabIndex = 15;
            // 
            // search
            // 
            this.search.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.search.Location = new System.Drawing.Point(451, 35);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(26, 22);
            this.search.TabIndex = 16;
            this.search.UseVisualStyleBackColor = true;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Sitka Text", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Info;
            this.label2.Location = new System.Drawing.Point(29, 536);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(518, 38);
            this.label2.TabIndex = 17;
            this.label2.Text = "Kindly Choose External Browser at Top Right Side if You face any incovinience.\r\nT" +
                "he Self Browser version is out of date. and Currently Can\'t update.";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Sitka Text", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Info;
            this.label3.Location = new System.Drawing.Point(474, -1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 19);
            this.label3.TabIndex = 18;
            this.label3.Text = "Time:";
            // 
            // dt
            // 
            this.dt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dt.AutoSize = true;
            this.dt.BackColor = System.Drawing.Color.Transparent;
            this.dt.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dt.ForeColor = System.Drawing.SystemColors.Info;
            this.dt.Location = new System.Drawing.Point(520, 22);
            this.dt.Name = "dt";
            this.dt.Size = new System.Drawing.Size(0, 15);
            this.dt.TabIndex = 19;
            // 
            // time
            // 
            this.time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.time.AutoSize = true;
            this.time.BackColor = System.Drawing.Color.Transparent;
            this.time.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time.ForeColor = System.Drawing.SystemColors.Info;
            this.time.Location = new System.Drawing.Point(520, 3);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(0, 15);
            this.time.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Sitka Text", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Info;
            this.label6.Location = new System.Drawing.Point(474, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 19);
            this.label6.TabIndex = 21;
            this.label6.Text = "Date:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmmaincontent
            // 
            this.AcceptButton = this.button1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(900, 573);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.time);
            this.Controls.Add(this.dt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.search);
            this.Controls.Add(this.searchbar);
            this.Controls.Add(this.ebrowser);
            this.Controls.Add(this.sbrowser);
            this.Controls.Add(this.notconn);
            this.Controls.Add(this.conn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.refresh);
            this.Controls.Add(this.frwd);
            this.Controls.Add(this.back);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmmaincontent";
            this.Text = "||SBTET||";
            this.Load += new System.EventHandler(this.frmmaincontent_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startPageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem facultyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sBTETToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem googleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sBTETToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem feePortalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resultsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gMailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem youTubeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem faceBookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem whatsAppWebToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem instagramToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contactToolStripMenuItem;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notificationsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentPortalToolStripMenuItem;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button frwd;
        private System.Windows.Forms.Button refresh;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button conn;
        private System.Windows.Forms.Button notconn;
        private System.Windows.Forms.RadioButton sbrowser;
        private System.Windows.Forms.RadioButton ebrowser;
        private System.Windows.Forms.ToolStripMenuItem googleToolStripMenuItem1;
        private System.Windows.Forms.TextBox searchbar;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label dt;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.BindingSource bindingSource1;

        public System.EventHandler sbrowser_CheckedChanged { get; set; }

        public System.EventHandler ebrowser_CheckedChanged { get; set; }
    }
}