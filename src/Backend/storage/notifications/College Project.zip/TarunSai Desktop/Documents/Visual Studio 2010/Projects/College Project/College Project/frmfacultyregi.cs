﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace College_Project
{
    public partial class frmfacultyregi : Form
    {
        public frmfacultyregi()
        {
            InitializeComponent();
        }



        private void txtfback_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmauthenticationform faf = new frmauthenticationform();
            faf.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnfpwhide_Click(object sender, EventArgs e)
        {
            if (btnfpwhide.Text == "Hide")
            {
                txtfpw.UseSystemPasswordChar = true;
                btnfpwshow.BringToFront();
            }
        }

        private void btnfpwshow_Click(object sender, EventArgs e)
        {
            if (txtfpw.Text != "")
            {
                txtfpw.UseSystemPasswordChar = false;
                btnfpwhide.BringToFront();
            }
        }

        private void txtfcpw_TextChanged(object sender, EventArgs e)
        {
            if (txtfpw.Text != txtfcpw.Text)
                labelpm.Text = "Password missmatch";
            else
                labelpm.Text = "";
        }

        private void btnfreg_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (txtfname.Text == "" || txtfqualification.Text == "" || txtfdepartment.Text == "" || txtfsub.Text == "" || txtfphno.Text == "" || txtfuid.Text == "")
                MessageBox.Show("Please Fill Above Fileds");
            else
                //  this.Hide();
                MessageBox.Show("HI\n Sir/Madam" + txtfname.Text + " \n Name:" + txtfname.Text + "\n Qualification:" + txtfqualification.Text + "\n Deapartment:" + txtfdepartment.Text + "\n Subject:" + txtfsub.Text + "\n Ph.No:" + txtfphno.Text + "\n UserID:" + txtfuid.Text + "\n Your Deatails Successfully Registered For Faculty Login \n\n Note: Kindly Remember Your User ID And Password  ");
            frmauthenticationform faf = new frmauthenticationform();
            faf.Show();
        }

        private void frmfacultyregi_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are u sure u want exit", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
