﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime;
using System.Runtime.InteropServices;

namespace College_Project
{
    public partial class frmmaincontent : Form
    {
        [DllImport("wininet.dll")]
        private extern static bool InternetGetConnectedState(out int Description, int Reservevalue);
        String S;

        public frmmaincontent(String A)
        {
            InitializeComponent();
            S = A;
        }
        public void web(string u) {
            int Desc;
            if (InternetGetConnectedState(out Desc, 0) == true)
            {              
                if(sbrowser.Checked==true){
                    webBrowser1.Show();
                    label2.Show();
                    search.Enabled = true;
                    searchbar.Enabled = true;
                    back.Enabled = true;
                    frwd.Enabled = true;
                    refresh.Enabled = true;
                    button2.Enabled = true;
                    webBrowser1.Navigate(u);
                }
                else if(ebrowser.Checked==true){
                    webBrowser1.Hide();
                    search.Enabled = false;
                    searchbar.Enabled = false;
                    back.Enabled = false;
                    frwd.Enabled = false;
                    refresh.Enabled = false;
                    button2.Enabled = false;
                    System.Diagnostics.Process.Start(u);
                }                        
            }
            else {
                if (MessageBox.Show("No Internet Connetion", "No Network", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error) == DialogResult.Retry) {
                    frmmaincontent frmc = new frmmaincontent(S);
                    frmc.Show();
                }   
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\t HI \nSorry for The Inconvinience\nThis PAGE is Still in Development ", "UNDER PROGRESS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        private void frmmaincontent_Load(object sender, EventArgs e)
        {
            timer1.Start();
            time.Text = DateTime.Now.ToLongTimeString();
            dt.Text = DateTime.Now.ToShortDateString();
            webBrowser1.Hide();
            label2.Hide();
            int Desc;
            if (InternetGetConnectedState(out Desc, 0) == true)
            {
                conn.BringToFront();
                label1.Text = "Connected";
                
            }
            else
            {
                notconn.BringToFront();
                label1.Text = "Not Connected";
            }
            if (S == "student")
            {
               

            }
            else if (S == "guest") {
                sBTETToolStripMenuItem1.Enabled = false;
                loginToolStripMenuItem.Enabled = false;
                //menuStrip1.Enabled = false;
                webBrowser1.Hide();
               
            }
            
            /*  switch()
              {
                  case google.Text :  System.Diagnostics.Process.Start("https://www.google.com");
                      break;
                  case facebook.Text : System.Diagnostics.Process.Start("https://www.google.com");
                      break;
                  default :  System.Diagnostics.Process.Start("https://www.google.com");
                      break;
              }*/
        }

        private void startPageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmauthenticationform login = new frmauthenticationform();
            login.Show();
        }

        private void facultyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmfacultyregi fr = new frmfacultyregi();
            fr.Show();
        }

        private void studentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmstdregi fs = new frmstdregi();
            fs.Show();
        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmauthenticationform login = new frmauthenticationform();
            login.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are u sure u want exit", "QUIT", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //System.Diagnostics.Process.Start("http://sbtetap.gov.in/Screens/MainHome.aspx");
            string u =("http://sbtetap.gov.in/Screens/MainHome.aspx");
            web(u);
        }

        private void notificationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("http://sbtetap.gov.in/Screens/Notifications.aspx");
           //System.Diagnostics.Process.Start("http://sbtetap.gov.in/Screens/Notifications.aspx");
        }

        private void homeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            web("https://sbtet.ap.gov.in/APSBTET/");
            //            System.Diagnostics.Process.Start("https://sbtet.ap.gov.in/APSBTET/");
        }

        private void feePortalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("https://sbtet.ap.gov.in/APSBTET/onlineExaminationPayment.do");
            //System.Diagnostics.Process.Start("https://sbtet.ap.gov.in/APSBTET/onlineExaminationPayment.do");
        }

        private void resultsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("https://sbtet.ap.gov.in/APSBTET/oep.do");
            //System.Diagnostics.Process.Start("https://sbtet.ap.gov.in/APSBTET/oep.do");
        }

        private void studentPortalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("https://apsbtet.net/studentportal/screens/mainstudentinfo.aspx");
            //System.Diagnostics.Process.Start("https://apsbtet.net/studentportal/screens/mainstudentinfo.aspx");
        }

        private void gMailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("https://accounts.google.com/b/0/AddMailService");
            //System.Diagnostics.Process.Start("https://accounts.google.com/b/0/AddMailService");
        }

        private void youTubeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("https://www.youtube.com/");
            //System.Diagnostics.Process.Start("https://www.youtube.com/");
        }

        private void whatsAppWebToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("https://web.whatsapp.com/");
            //System.Diagnostics.Process.Start("https://web.whatsapp.com/");
        }

        private void faceBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("https://www.facebook.com/");
            //System.Diagnostics.Process.Start("https://www.facebook.com/");
        }

        private void instagramToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("https://www.instagram.com/");
            //System.Diagnostics.Process.Start("https://www.instagram.com/");
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("http://sbtetap.gov.in/Screens/History.aspx");
            //System.Diagnostics.Process.Start("http://sbtetap.gov.in/Screens/History.aspx");
        }

        private void contactToolStripMenuItem_Click(object sender, EventArgs e)
        {
            web("http://sbtetap.gov.in/Screens/ContactUs.aspx");
            //System.Diagnostics.Process.Start("http://sbtetap.gov.in/Screens/ContactUs.aspx");
        }

        private void guestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmmaincontent fm = new frmmaincontent("Guest");
            fm.Show();
        }

        private void webBrowser1_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            String w = webBrowser1.Url.ToString();
           // webBrowser1.Navigate(w);
            searchbar.Text = w;
            web(w);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void frwd_Click(object sender, EventArgs e)
        {
            webBrowser1.GoForward();
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            webBrowser1.GoHome();
        }

        private void googleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            web("https://www.google.com");
        }
        private void search_Click(object sender, EventArgs e)
        {
            web(searchbar.Text);
        }

        private void notconn_Click(object sender, EventArgs e)
        {
            int Desc;
            if (InternetGetConnectedState(out Desc, 0) == true)
            {
                conn.BringToFront();
                label1.Text = "Connected";

            }
            else
            {
                notconn.BringToFront();
                label1.Text = "Not Connected";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }
    }
}
