﻿namespace College_Project
{
    partial class frmstdregi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmstdregi));
            this.btnspwshow = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtscpw = new System.Windows.Forms.TextBox();
            this.txtspw = new System.Windows.Forms.TextBox();
            this.txtspinno = new System.Windows.Forms.TextBox();
            this.txtsphno = new System.Windows.Forms.TextBox();
            this.txtsdepartment = new System.Windows.Forms.TextBox();
            this.txtsqualification = new System.Windows.Forms.TextBox();
            this.txtsname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelpm = new System.Windows.Forms.Label();
            this.btnspwhide = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtsback = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnspwshow
            // 
            this.btnspwshow.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnspwshow.Location = new System.Drawing.Point(307, 265);
            this.btnspwshow.Name = "btnspwshow";
            this.btnspwshow.Size = new System.Drawing.Size(44, 21);
            this.btnspwshow.TabIndex = 47;
            this.btnspwshow.Text = "show";
            this.btnspwshow.UseVisualStyleBackColor = true;
            this.btnspwshow.Click += new System.EventHandler(this.btnspwshow_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 335);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(252, 13);
            this.label10.TabIndex = 46;
            this.label10.Text = "Note: Please Remember your user ID and Password";
            // 
            // button1
            // 
            this.button1.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Location = new System.Drawing.Point(125, 361);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 34);
            this.button1.TabIndex = 45;
            this.button1.Text = "Register";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtscpw
            // 
            this.txtscpw.Location = new System.Drawing.Point(180, 293);
            this.txtscpw.Name = "txtscpw";
            this.txtscpw.Size = new System.Drawing.Size(170, 20);
            this.txtscpw.TabIndex = 44;
            this.txtscpw.TextChanged += new System.EventHandler(this.txtscpw_TextChanged);
            // 
            // txtspw
            // 
            this.txtspw.Location = new System.Drawing.Point(181, 265);
            this.txtspw.Name = "txtspw";
            this.txtspw.Size = new System.Drawing.Size(170, 20);
            this.txtspw.TabIndex = 43;
            // 
            // txtspinno
            // 
            this.txtspinno.Location = new System.Drawing.Point(180, 239);
            this.txtspinno.Name = "txtspinno";
            this.txtspinno.Size = new System.Drawing.Size(170, 20);
            this.txtspinno.TabIndex = 42;
            // 
            // txtsphno
            // 
            this.txtsphno.Location = new System.Drawing.Point(180, 213);
            this.txtsphno.Name = "txtsphno";
            this.txtsphno.Size = new System.Drawing.Size(170, 20);
            this.txtsphno.TabIndex = 41;
            // 
            // txtsdepartment
            // 
            this.txtsdepartment.Location = new System.Drawing.Point(180, 187);
            this.txtsdepartment.Name = "txtsdepartment";
            this.txtsdepartment.Size = new System.Drawing.Size(170, 20);
            this.txtsdepartment.TabIndex = 39;
            // 
            // txtsqualification
            // 
            this.txtsqualification.Location = new System.Drawing.Point(180, 161);
            this.txtsqualification.Name = "txtsqualification";
            this.txtsqualification.Size = new System.Drawing.Size(170, 20);
            this.txtsqualification.TabIndex = 38;
            // 
            // txtsname
            // 
            this.txtsname.Location = new System.Drawing.Point(180, 135);
            this.txtsname.Name = "txtsname";
            this.txtsname.Size = new System.Drawing.Size(170, 20);
            this.txtsname.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(10, 285);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(164, 28);
            this.label9.TabIndex = 36;
            this.label9.Text = "Confirm Password:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(11, 257);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 28);
            this.label8.TabIndex = 35;
            this.label8.Text = "Password:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(11, 231);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 28);
            this.label7.TabIndex = 34;
            this.label7.Text = "Pin No.:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(11, 205);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 28);
            this.label6.TabIndex = 33;
            this.label6.Text = "Phone No.:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 28);
            this.label4.TabIndex = 31;
            this.label4.Text = "Department";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 28);
            this.label3.TabIndex = 30;
            this.label3.Text = "Qualification:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sitka Heading", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 28);
            this.label2.TabIndex = 29;
            this.label2.Text = "Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Sitka Small", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Location = new System.Drawing.Point(27, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(311, 106);
            this.label1.TabIndex = 28;
            this.label1.Text = "STUDENT \r\nREGISTRATION";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelpm
            // 
            this.labelpm.AutoSize = true;
            this.labelpm.Location = new System.Drawing.Point(181, 322);
            this.labelpm.Name = "labelpm";
            this.labelpm.Size = new System.Drawing.Size(0, 13);
            this.labelpm.TabIndex = 51;
            // 
            // btnspwhide
            // 
            this.btnspwhide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnspwhide.Location = new System.Drawing.Point(307, 266);
            this.btnspwhide.Name = "btnspwhide";
            this.btnspwhide.Size = new System.Drawing.Size(43, 20);
            this.btnspwhide.TabIndex = 52;
            this.btnspwhide.Text = "Hide";
            this.btnspwhide.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnspwhide.UseVisualStyleBackColor = true;
            this.btnspwhide.Click += new System.EventHandler(this.btnfpwhide_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Image = global::College_Project.Properties.Resources.de5292847c7a485cbc466895d0398372c7f3eeb3;
            this.button3.Location = new System.Drawing.Point(343, 1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(24, 23);
            this.button3.TabIndex = 50;
            this.button3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtsback
            // 
            this.txtsback.Image = global::College_Project.Properties.Resources.back1;
            this.txtsback.Location = new System.Drawing.Point(17, 361);
            this.txtsback.Name = "txtsback";
            this.txtsback.Size = new System.Drawing.Size(44, 34);
            this.txtsback.TabIndex = 49;
            this.txtsback.UseVisualStyleBackColor = true;
            this.txtsback.Click += new System.EventHandler(this.txtsback_Click);
            // 
            // frmstdregi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ClientSize = new System.Drawing.Size(368, 420);
            this.Controls.Add(this.btnspwshow);
            this.Controls.Add(this.btnspwhide);
            this.Controls.Add(this.labelpm);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.txtsback);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtscpw);
            this.Controls.Add(this.txtspw);
            this.Controls.Add(this.txtspinno);
            this.Controls.Add(this.txtsphno);
            this.Controls.Add(this.txtsdepartment);
            this.Controls.Add(this.txtsqualification);
            this.Controls.Add(this.txtsname);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmstdregi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student Registration";
            this.Load += new System.EventHandler(this.frmstdregi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnspwshow;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtscpw;
        private System.Windows.Forms.TextBox txtspw;
        private System.Windows.Forms.TextBox txtspinno;
        private System.Windows.Forms.TextBox txtsphno;
        private System.Windows.Forms.TextBox txtsdepartment;
        private System.Windows.Forms.TextBox txtsqualification;
        private System.Windows.Forms.TextBox txtsname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button txtsback;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label labelpm;
        private System.Windows.Forms.Button btnspwhide;
    }
}