﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace College_Project
{
    public partial class frmstdregi : Form
    {
        public frmstdregi()
        {
            InitializeComponent();
        }

        private void txtsback_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmauthenticationform faf = new frmauthenticationform();
            faf.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are u sure u want exit", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (txtsname.Text == "" || txtsqualification.Text == "" || txtsdepartment.Text == "" || txtsphno.Text == "" || txtspinno.Text == "")
                MessageBox.Show("Please Fill The Fields");
            else
           // this.Hide();
            MessageBox.Show("HI\n Mr./Ms."+txtsname.Text+" \n Name:"+ txtsname.Text + "\n Qualification:"+ txtsqualification.Text+"\n Deapartment:" +txtsdepartment.Text+"\n Ph.No:"+txtsphno.Text+"\n Pin no:"+txtspinno.Text+"\n Your Deatails Successfully Registered For Student Login \n\n Note: Kindly Remember Your Pin no And Password  ");
            frmauthenticationform faf = new frmauthenticationform();
            faf.Show();
        }

        private void txtscpw_TextChanged(object sender, EventArgs e)
        {
            if (txtspw.Text != txtscpw.Text)
                labelpm.Text = "Password missmatch";
            else
                labelpm.Text = "";
        }

        private void btnfpwhide_Click(object sender, EventArgs e)
        {
            if (btnspwhide.Text == "Hide")
            {
                txtspw.UseSystemPasswordChar = true;
                btnspwshow.BringToFront();
            }
        }

        private void btnspwshow_Click(object sender, EventArgs e)
        {
            if (btnspwshow.Text == "Show")
            {
                txtspw.UseSystemPasswordChar = false;
                btnspwhide.BringToFront();
            }
        }

        private void frmstdregi_Load(object sender, EventArgs e)
        {

        }
    }
}
