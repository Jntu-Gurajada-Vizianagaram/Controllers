﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace College_Project
{
    public partial class frmauthenticationform : Form
    {
        public frmauthenticationform()
        {
            InitializeComponent();
        }

        private void fctyregi_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            frmfacultyregi fctreg = new frmfacultyregi();
            fctreg.Show();
        }

        private void stdregi_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            frmstdregi stdreg = new frmstdregi();
            stdreg.Show();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are u sure u want exit", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void frmauthenticationform_Load(object sender, EventArgs e)
        {

            panel1.Enabled = false;
            panel2.Enabled = false;
            
        }

        private void facultylogin_CheckedChanged(object sender, EventArgs e)
        {
            panel1.Enabled = true;
            panel2.Enabled = false;
            txtpinno.Clear();
            txtspw.Clear();
        }

        private void studentlogin_CheckedChanged(object sender, EventArgs e)
        {
            panel1.Enabled = false;
            panel2.Enabled = true;
            txtuserid.Clear();
            txtfpw.Clear();
        }

        private void btnflogin_Click(object sender, EventArgs e)
        {
            
            if(txtuserid.Text=="faculty" && txtfpw.Text=="1234567" )
            {
            this.Hide();
            frmmaincontent fmc= new frmmaincontent(txtuserid.Text);
            fmc.Show();
            }
            else{
                MessageBox.Show("Inavlid Username or Password\n\n Try Again");
            }
        }

        private void btnslogin_Click(object sender, EventArgs e)
        {
            if (txtpinno.Text == "student"   && txtspw.Text == "1234567")
            {
                this.Hide();
                frmmaincontent fmc = new frmmaincontent(txtpinno.Text);
                fmc.Show();
            }
            else
            {
                MessageBox.Show("Inavlid Username or Password\n\n Try Again");
            }
        }

        private void btnfpwshow_Click(object sender, EventArgs e)
        {
            if (txtfpw.Text!="")
            {
                txtfpw.UseSystemPasswordChar = false;
                btnfpwhide.BringToFront();
            }
        }

        private void btnfpwhide_Click(object sender, EventArgs e)
        {
            if (txtfpw.Text!="")
            {
                txtfpw.UseSystemPasswordChar = true;
                btnfpwshow.BringToFront();
            }
        }

        private void btnspwshow_Click(object sender, EventArgs e)
        {
            if (txtspw.Text != "")
            {
                txtspw.UseSystemPasswordChar = false;
                btnspwhide.BringToFront();
            }
        }

        private void btnspwhide_Click(object sender, EventArgs e)
        {
            if (txtspw.Text != "")
            {
                txtspw.UseSystemPasswordChar = true;
                btnspwshow.BringToFront();
            }
        }

        private void btnguest_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmmaincontent fmc = new frmmaincontent("guest");
            fmc.Show();
        }        
      }

        
    }
