﻿namespace College_Project
{
    partial class frmauthenticationform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmauthenticationform));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnfpwshow = new System.Windows.Forms.Button();
            this.btnfpwhide = new System.Windows.Forms.Button();
            this.fctyregi = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.btnflogin = new System.Windows.Forms.Button();
            this.txtfpw = new System.Windows.Forms.TextBox();
            this.txtuserid = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.facultylogin = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnspwshow = new System.Windows.Forms.Button();
            this.btnspwhide = new System.Windows.Forms.Button();
            this.stdregi = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.btnslogin = new System.Windows.Forms.Button();
            this.txtspw = new System.Windows.Forms.TextBox();
            this.txtpinno = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.studentlogin = new System.Windows.Forms.RadioButton();
            this.button3 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.btnguest = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Sitka Text", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(248, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 53);
            this.label1.TabIndex = 0;
            this.label1.Text = "AUTHENTICATION";
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.BackgroundImage = global::College_Project.Properties.Resources.images_ico;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.btnfpwshow);
            this.panel1.Controls.Add(this.btnfpwhide);
            this.panel1.Controls.Add(this.fctyregi);
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Controls.Add(this.btnflogin);
            this.panel1.Controls.Add(this.txtfpw);
            this.panel1.Controls.Add(this.txtuserid);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(25, 111);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 311);
            this.panel1.TabIndex = 1;
            // 
            // btnfpwshow
            // 
            this.btnfpwshow.BackColor = System.Drawing.Color.Transparent;
            this.btnfpwshow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnfpwshow.Image = global::College_Project.Properties.Resources.show;
            this.btnfpwshow.Location = new System.Drawing.Point(317, 98);
            this.btnfpwshow.Name = "btnfpwshow";
            this.btnfpwshow.Size = new System.Drawing.Size(29, 20);
            this.btnfpwshow.TabIndex = 5;
            this.btnfpwshow.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnfpwshow.UseVisualStyleBackColor = false;
            this.btnfpwshow.Click += new System.EventHandler(this.btnfpwshow_Click);
            // 
            // btnfpwhide
            // 
            this.btnfpwhide.BackColor = System.Drawing.Color.Transparent;
            this.btnfpwhide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnfpwhide.Image = global::College_Project.Properties.Resources.hide1;
            this.btnfpwhide.Location = new System.Drawing.Point(317, 98);
            this.btnfpwhide.Name = "btnfpwhide";
            this.btnfpwhide.Size = new System.Drawing.Size(30, 20);
            this.btnfpwhide.TabIndex = 6;
            this.btnfpwhide.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnfpwhide.UseVisualStyleBackColor = false;
            this.btnfpwhide.Click += new System.EventHandler(this.btnfpwhide_Click);
            // 
            // fctyregi
            // 
            this.fctyregi.AutoSize = true;
            this.fctyregi.BackColor = System.Drawing.Color.LightGray;
            this.fctyregi.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fctyregi.Location = new System.Drawing.Point(134, 256);
            this.fctyregi.Name = "fctyregi";
            this.fctyregi.Size = new System.Drawing.Size(115, 16);
            this.fctyregi.TabIndex = 3;
            this.fctyregi.TabStop = true;
            this.fctyregi.Text = "New  Rgistration";
            this.fctyregi.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.fctyregi_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.SkyBlue;
            this.linkLabel1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(230, 131);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(117, 16);
            this.linkLabel1.TabIndex = 4;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Forgot Password";
            // 
            // btnflogin
            // 
            this.btnflogin.BackColor = System.Drawing.Color.SkyBlue;
            this.btnflogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnflogin.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnflogin.Location = new System.Drawing.Point(144, 193);
            this.btnflogin.Name = "btnflogin";
            this.btnflogin.Size = new System.Drawing.Size(100, 30);
            this.btnflogin.TabIndex = 2;
            this.btnflogin.Text = "Login";
            this.btnflogin.UseVisualStyleBackColor = false;
            this.btnflogin.Click += new System.EventHandler(this.btnflogin_Click);
            // 
            // txtfpw
            // 
            this.txtfpw.Location = new System.Drawing.Point(164, 98);
            this.txtfpw.Name = "txtfpw";
            this.txtfpw.Size = new System.Drawing.Size(183, 20);
            this.txtfpw.TabIndex = 1;
            this.txtfpw.Tag = "";
            this.txtfpw.UseSystemPasswordChar = true;
            // 
            // txtuserid
            // 
            this.txtuserid.Location = new System.Drawing.Point(164, 41);
            this.txtuserid.Multiline = true;
            this.txtuserid.Name = "txtuserid";
            this.txtuserid.Size = new System.Drawing.Size(184, 20);
            this.txtuserid.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.SkyBlue;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(43, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 21);
            this.label5.TabIndex = 3;
            this.label5.Text = "Password:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.SkyBlue;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(43, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 21);
            this.label4.TabIndex = 2;
            this.label4.Text = "User ID:";
            // 
            // facultylogin
            // 
            this.facultylogin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.facultylogin.AutoSize = true;
            this.facultylogin.BackColor = System.Drawing.Color.Transparent;
            this.facultylogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.facultylogin.Location = new System.Drawing.Point(72, 74);
            this.facultylogin.Name = "facultylogin";
            this.facultylogin.Size = new System.Drawing.Size(278, 37);
            this.facultylogin.TabIndex = 0;
            this.facultylogin.Text = "FACULTY LOGIN";
            this.facultylogin.UseVisualStyleBackColor = false;
            this.facultylogin.CheckedChanged += new System.EventHandler(this.facultylogin_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel2.BackgroundImage = global::College_Project.Properties.Resources.images_ico;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.btnspwshow);
            this.panel2.Controls.Add(this.btnspwhide);
            this.panel2.Controls.Add(this.stdregi);
            this.panel2.Controls.Add(this.linkLabel2);
            this.panel2.Controls.Add(this.btnslogin);
            this.panel2.Controls.Add(this.txtspw);
            this.panel2.Controls.Add(this.txtpinno);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(495, 111);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 311);
            this.panel2.TabIndex = 2;
            // 
            // btnspwshow
            // 
            this.btnspwshow.BackColor = System.Drawing.Color.Transparent;
            this.btnspwshow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnspwshow.Image = global::College_Project.Properties.Resources.show;
            this.btnspwshow.Location = new System.Drawing.Point(296, 101);
            this.btnspwshow.Name = "btnspwshow";
            this.btnspwshow.Size = new System.Drawing.Size(29, 20);
            this.btnspwshow.TabIndex = 6;
            this.btnspwshow.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnspwshow.UseVisualStyleBackColor = false;
            this.btnspwshow.Click += new System.EventHandler(this.btnspwshow_Click);
            // 
            // btnspwhide
            // 
            this.btnspwhide.BackColor = System.Drawing.Color.Transparent;
            this.btnspwhide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnspwhide.Image = global::College_Project.Properties.Resources.hide1;
            this.btnspwhide.Location = new System.Drawing.Point(296, 101);
            this.btnspwhide.Name = "btnspwhide";
            this.btnspwhide.Size = new System.Drawing.Size(29, 20);
            this.btnspwhide.TabIndex = 6;
            this.btnspwhide.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnspwhide.UseVisualStyleBackColor = false;
            this.btnspwhide.Click += new System.EventHandler(this.btnspwhide_Click);
            // 
            // stdregi
            // 
            this.stdregi.AutoSize = true;
            this.stdregi.BackColor = System.Drawing.Color.LightGray;
            this.stdregi.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stdregi.Location = new System.Drawing.Point(136, 251);
            this.stdregi.Name = "stdregi";
            this.stdregi.Size = new System.Drawing.Size(115, 16);
            this.stdregi.TabIndex = 3;
            this.stdregi.TabStop = true;
            this.stdregi.Text = "New  Rgistration";
            this.stdregi.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.stdregi_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.BackColor = System.Drawing.Color.SkyBlue;
            this.linkLabel2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.Location = new System.Drawing.Point(208, 131);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(117, 16);
            this.linkLabel2.TabIndex = 4;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Forgot Password";
            // 
            // btnslogin
            // 
            this.btnslogin.BackColor = System.Drawing.Color.SkyBlue;
            this.btnslogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnslogin.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnslogin.Location = new System.Drawing.Point(142, 193);
            this.btnslogin.Name = "btnslogin";
            this.btnslogin.Size = new System.Drawing.Size(100, 30);
            this.btnslogin.TabIndex = 2;
            this.btnslogin.Text = "Login";
            this.btnslogin.UseVisualStyleBackColor = false;
            this.btnslogin.Click += new System.EventHandler(this.btnslogin_Click);
            // 
            // txtspw
            // 
            this.txtspw.Location = new System.Drawing.Point(142, 101);
            this.txtspw.Name = "txtspw";
            this.txtspw.Size = new System.Drawing.Size(183, 20);
            this.txtspw.TabIndex = 1;
            this.txtspw.UseSystemPasswordChar = true;
            // 
            // txtpinno
            // 
            this.txtpinno.Location = new System.Drawing.Point(142, 41);
            this.txtpinno.Name = "txtpinno";
            this.txtpinno.Size = new System.Drawing.Size(183, 20);
            this.txtpinno.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.SkyBlue;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(42, 98);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 21);
            this.label7.TabIndex = 5;
            this.label7.Text = "Password:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.SkyBlue;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(42, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 21);
            this.label6.TabIndex = 4;
            this.label6.Text = "Pin No.:";
            // 
            // studentlogin
            // 
            this.studentlogin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.studentlogin.AutoSize = true;
            this.studentlogin.BackColor = System.Drawing.Color.Transparent;
            this.studentlogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentlogin.Location = new System.Drawing.Point(541, 80);
            this.studentlogin.Name = "studentlogin";
            this.studentlogin.Size = new System.Drawing.Size(282, 37);
            this.studentlogin.TabIndex = 1;
            this.studentlogin.Text = "STUDENT LOGIN";
            this.studentlogin.UseVisualStyleBackColor = false;
            this.studentlogin.CheckedChanged += new System.EventHandler(this.studentlogin_CheckedChanged);
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Image = global::College_Project.Properties.Resources.de5292847c7a485cbc466895d0398372c7f3eeb3;
            this.button3.Location = new System.Drawing.Point(892, 9);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(24, 23);
            this.button3.TabIndex = 2;
            this.button3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(356, 437);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Please select the required Option To Login";
            // 
            // btnguest
            // 
            this.btnguest.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnguest.BackColor = System.Drawing.Color.Lime;
            this.btnguest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnguest.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnguest.Location = new System.Drawing.Point(570, 433);
            this.btnguest.Name = "btnguest";
            this.btnguest.Size = new System.Drawing.Size(52, 20);
            this.btnguest.TabIndex = 12;
            this.btnguest.Text = "Guest";
            this.btnguest.UseVisualStyleBackColor = false;
            this.btnguest.Click += new System.EventHandler(this.btnguest_Click);
            // 
            // frmauthenticationform
            // 
            this.AcceptButton = this.btnflogin;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::College_Project.Properties.Resources.WhatsApp_Image_2021_06_12_at_12_47_54;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(927, 471);
            this.Controls.Add(this.btnguest);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.facultylogin);
            this.Controls.Add(this.studentlogin);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frmauthenticationform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Authentication";
            this.Load += new System.EventHandler(this.frmauthenticationform_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton facultylogin;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton studentlogin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.LinkLabel fctyregi;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button btnflogin;
        private System.Windows.Forms.TextBox txtfpw;
        private System.Windows.Forms.TextBox txtuserid;
        private System.Windows.Forms.LinkLabel stdregi;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Button btnslogin;
        private System.Windows.Forms.TextBox txtspw;
        private System.Windows.Forms.TextBox txtpinno;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnfpwshow;
        private System.Windows.Forms.Button btnfpwhide;
        private System.Windows.Forms.Button btnspwshow;
        private System.Windows.Forms.Button btnspwhide;
        private System.Windows.Forms.Button btnguest;
    }
}